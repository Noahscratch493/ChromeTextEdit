console.log('Opened ChromeTextEdit');
